# INFO232 - Mini-projet
This GitHub repository aims to share teaching resources for L2 students enrolled in the course INFO232 (mini-projet) at University Paris-Saclay.

For more instructions for each TP, please go to the corresponding folder.


<img src="https://www.universite-paris-saclay.fr/profiles/saclay/themes/saclay_v2/logo.svg" height="100">

The authors include: Isabelle Guyon, Zhengying Liu, Adrien pavao, Balthazar Donon, Herilalaina Rakotoarison, and Victor Estrade.
